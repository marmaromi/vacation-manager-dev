import VacationList from "../../VacationArea/VacationList/VacationList";

function Main(): JSX.Element {

    return (
        <div className="Main">

        <VacationList />
        </div>
    );
}

export default Main;
