import "./Footer.css";

function Footer(): JSX.Element {
    return (
        <div className="Footer">
			footer
        </div>
    );
}

export default Footer;
