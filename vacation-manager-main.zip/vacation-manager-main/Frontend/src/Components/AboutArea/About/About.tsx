import "./About.css";

function About(): JSX.Element {
    return (
        <div className="About">
			
        </div>
    );
}

export default About;
