import "./Reports.css";

function Reports(): JSX.Element {
    return (
        <div className="Reports">
			
        </div>
    );
}

export default Reports;
