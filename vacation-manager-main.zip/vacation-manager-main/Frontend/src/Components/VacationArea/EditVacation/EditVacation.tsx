import "./EditVacation.css";

function EditVacation(): JSX.Element {
    return (
        <div className="EditVacation">
			
        </div>
    );
}

export default EditVacation;
