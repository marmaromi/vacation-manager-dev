enum Role {
    User = "user",
    Admin = "admin"
}

export default Role;