import "./AuthMenu.css";

function AuthMenu(): JSX.Element {
    return (
        <div className="AuthMenu">
			
        </div>
    );
}

export default AuthMenu;
