import "./logout.css";

function Logout(): JSX.Element {
    return (
        <div className="logout">
			
        </div>
    );
}

export default Logout;
