import "./Loading.css";

function Loading(): JSX.Element {
    return (
        <div className="Loading">
			
        </div>
    );
}

export default Loading;
