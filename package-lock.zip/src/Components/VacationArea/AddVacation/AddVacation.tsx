import "./AddVacation.css";

function AddVacation(): JSX.Element {
    return (
        <div className="AddVacation">
			
        </div>
    );
}

export default AddVacation;
